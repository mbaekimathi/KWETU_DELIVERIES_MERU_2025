#!/usr/bin/env python3
"""
Local Network Printer Scanner Agent
For use with cPanel and shared hosting environments

This script can be run as a cron job or called via API to scan for WiFi printers
on the local network. It's designed to work in restricted hosting environments.

Usage:
    python3 scan_printers_agent.py [network_range]
    
    Example:
    python3 scan_printers_agent.py 192.168.1
    
    Or set as cron job:
    */5 * * * * /usr/bin/python3 /path/to/scan_printers_agent.py 192.168.1 >> /tmp/printer_scan.log 2>&1
"""

import socket
import sys
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# Common thermal printer ports
THERMAL_PORTS = [9100, 9101, 9102, 515, 631, 80, 443]

def test_printer_port(ip, port, timeout=0.5):
    """Test if a specific IP:port is a thermal printer"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((ip, port))
        
        if result == 0:
            # Port is open, test if it's a thermal printer
            try:
                # Send ESC/POS initialization command
                sock.send(b'\x1B\x40')  # ESC @
                time.sleep(0.1)
                
                # Try to get printer info
                try:
                    sock.send(b'\x1D\x49\x01')  # Get printer ID
                except:
                    pass
                
                return {
                    'ip': ip,
                    'port': port,
                    'name': f'Thermal Printer at {ip}:{port}',
                    'model': 'ESC/POS Thermal Printer',
                    'type': 'thermal',
                    'status': 'available',
                    'discovery_method': 'Network Scan',
                    'timestamp': datetime.now().isoformat()
                }
            except Exception as e:
                # Port is open but might not be a printer
                return {
                    'ip': ip,
                    'port': port,
                    'name': f'Device at {ip}:{port}',
                    'model': 'Unknown Device',
                    'type': 'unknown',
                    'status': 'available',
                    'discovery_method': 'Network Scan',
                    'timestamp': datetime.now().isoformat()
                }
        sock.close()
    except Exception as e:
        pass
    finally:
        try:
            sock.close()
        except:
            pass
    return None

def scan_network_range(network_base, start=1, end=254, max_workers=20):
    """Scan a network range for thermal printers"""
    discovered_printers = []
    
    print(f"Scanning {network_base}.{start}-{end} for thermal printers...")
    print(f"Testing ports: {', '.join(map(str, THERMAL_PORTS))}")
    
    def scan_ip(ip_num):
        ip = f"{network_base}.{ip_num}"
        printers_found = []
        
        for port in THERMAL_PORTS:
            result = test_printer_port(ip, port)
            if result:
                printers_found.append(result)
                print(f"[FOUND] {result['name']} - {result['ip']}:{result['port']}")
        
        return printers_found
    
    # Use threading for faster scanning
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(scan_ip, i) for i in range(start, end + 1)]
        
        for future in as_completed(futures, timeout=60):
            try:
                results = future.result(timeout=2)
                if results:
                    discovered_printers.extend(results)
            except Exception as e:
                continue
    
    return discovered_printers

def scan_arp_table(network_base):
    """Scan ARP table for active devices and test for printers"""
    discovered_printers = []
    
    try:
        import subprocess
        import re
        
        print("Scanning ARP table for active devices...")
        result = subprocess.run(['arp', '-a'], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            # Extract IPs from ARP table
            ips = set(re.findall(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', result.stdout))
            
            # Filter to our network
            network_prefix = '.'.join(network_base.split('.')[:3])
            network_ips = [ip for ip in ips if ip.startswith(network_prefix)]
            
            print(f"Found {len(network_ips)} active devices in ARP table")
            
            # Test each IP for printer ports
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = []
                for ip in network_ips:
                    for port in THERMAL_PORTS:
                        futures.append(executor.submit(test_printer_port, ip, port))
                
                for future in as_completed(futures, timeout=30):
                    try:
                        result = future.result(timeout=1)
                        if result:
                            discovered_printers.append(result)
                            print(f"[FOUND] {result['name']} - {result['ip']}:{result['port']}")
                    except:
                        continue
    except Exception as e:
        print(f"[WARNING] ARP scan failed: {e}")
    
    return discovered_printers

def main():
    """Main scanning function"""
    # Get network range from command line or use default
    if len(sys.argv) > 1:
        network_range = sys.argv[1]
    else:
        # Try to auto-detect
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            if local_ip.startswith('192.168.') or local_ip.startswith('10.') or local_ip.startswith('172.'):
                network_range = '.'.join(local_ip.split('.')[:-1])
            else:
                network_range = '192.168.1'
        except:
            network_range = '192.168.1'
    
    print(f"=== Thermal Printer Scanner Agent ===")
    print(f"Network Range: {network_range}")
    print(f"Start Time: {datetime.now().isoformat()}")
    print("=" * 50)
    
    all_printers = []
    
    # Method 1: Network Range Scan
    print("\n[Method 1] Scanning network range...")
    network_printers = scan_network_range(network_range, start=1, end=254)
    all_printers.extend(network_printers)
    
    # Method 2: ARP Table Scan
    print("\n[Method 2] Scanning ARP table...")
    arp_printers = scan_arp_table(network_range)
    # Remove duplicates
    existing_ips = {(p['ip'], p['port']) for p in all_printers}
    for printer in arp_printers:
        if (printer['ip'], printer['port']) not in existing_ips:
            all_printers.append(printer)
    
    # Output results
    print("\n" + "=" * 50)
    print(f"Scan Complete: {datetime.now().isoformat()}")
    print(f"Total Printers Found: {len(all_printers)}")
    print("=" * 50)
    
    # Output as JSON for API consumption
    output = {
        'success': True,
        'printers': all_printers,
        'count': len(all_printers),
        'network_range': network_range,
        'scan_time': datetime.now().isoformat(),
        'scan_methods': ['network_range', 'arp_table']
    }
    
    # Save to file for API to read
    output_file = '/tmp/printer_scan_results.json'
    try:
        with open(output_file, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"\nResults saved to: {output_file}")
    except Exception as e:
        print(f"\n[WARNING] Could not save results to file: {e}")
    
    # Also print JSON to stdout
    print("\n" + json.dumps(output, indent=2))
    
    return output

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nScan interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Scan failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)








